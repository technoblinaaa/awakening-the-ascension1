import { motion } from 'framer-motion';

interface Props {
  size?: number;
  opacity?: number;
  className?: string;
  variant?: 'sigil' | 'merkaba' | 'flower' | 'hexagon';
}

export function Sigil({ size = 260, opacity = 0.18, className = '' }: Props) {
  const cx = size / 2;
  const cy = size / 2;
  const r1 = size * 0.45;
  const r2 = size * 0.3;
  const r3 = size * 0.15;

  const hexPoints = (radius: number) =>
    Array.from({ length: 6 }, (_, i) => {
      const a = (Math.PI / 3) * i - Math.PI / 6;
      return `${cx + radius * Math.cos(a)},${cy + radius * Math.sin(a)}`;
    }).join(' ');

  const triangleUp = (r: number) =>
    Array.from({ length: 3 }, (_, i) => {
      const a = (Math.PI * 2 / 3) * i - Math.PI / 2;
      return `${cx + r * Math.cos(a)},${cy + r * Math.sin(a)}`;
    }).join(' ');

  const triangleDown = (r: number) =>
    Array.from({ length: 3 }, (_, i) => {
      const a = (Math.PI * 2 / 3) * i + Math.PI / 2;
      return `${cx + r * Math.cos(a)},${cy + r * Math.sin(a)}`;
    }).join(' ');

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      className={className}
      style={{ opacity }}
      fill="none"
    >
      <defs>
        <radialGradient id="sigilGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#d47fe6" />
          <stop offset="50%" stopColor="#8b2da8" />
          <stop offset="100%" stopColor="#c9a84c" />
        </radialGradient>
        <filter id="sigilGlow">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      {/* Outer circle */}
      <circle cx={cx} cy={cy} r={r1} stroke="url(#sigilGrad)" strokeWidth="0.7" />
      {/* Mid circle */}
      <circle cx={cx} cy={cy} r={r2} stroke="url(#sigilGrad)" strokeWidth="0.5" />
      {/* Inner circle */}
      <circle cx={cx} cy={cy} r={r3} stroke="url(#sigilGrad)" strokeWidth="0.5" />
      {/* Hexagons */}
      <polygon points={hexPoints(r1)} stroke="url(#sigilGrad)" strokeWidth="0.6" />
      <polygon points={hexPoints(r2)} stroke="url(#sigilGrad)" strokeWidth="0.5" />
      {/* Star of David */}
      <polygon points={triangleUp(r1 * 0.88)} stroke="url(#sigilGrad)" strokeWidth="0.6" />
      <polygon points={triangleDown(r1 * 0.88)} stroke="url(#sigilGrad)" strokeWidth="0.6" />
      <polygon points={triangleUp(r2 * 0.9)} stroke="url(#sigilGrad)" strokeWidth="0.4" />
      <polygon points={triangleDown(r2 * 0.9)} stroke="url(#sigilGrad)" strokeWidth="0.4" />

      {/* Spokes */}
      {Array.from({ length: 12 }, (_, i) => {
        const a = (Math.PI / 6) * i;
        return (
          <line
            key={i}
            x1={cx + r3 * Math.cos(a)}
            y1={cy + r3 * Math.sin(a)}
            x2={cx + r1 * Math.cos(a)}
            y2={cy + r1 * Math.sin(a)}
            stroke="url(#sigilGrad)"
            strokeWidth="0.4"
          />
        );
      })}

      {/* Center dot */}
      <circle cx={cx} cy={cy} r={3} fill="url(#sigilGrad)" />
    </svg>
  );
}

export function FloatingSigil() {
  return (
    <div className="relative flex items-center justify-center" style={{ width: 340, height: 340 }}>
      {/* Outermost slow ring */}
      <motion.div
        className="absolute"
        animate={{ rotate: 360 }}
        transition={{ duration: 90, repeat: Infinity, ease: 'linear' }}
      >
        <Sigil size={340} opacity={0.35} />
      </motion.div>

      {/* Mid counter-rotate */}
      <motion.div
        className="absolute"
        animate={{ rotate: -360 }}
        transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
      >
        <Sigil size={230} opacity={0.45} />
      </motion.div>

      {/* Inner fast rotate */}
      <motion.div
        className="absolute"
        animate={{ rotate: 360 }}
        transition={{ duration: 35, repeat: Infinity, ease: 'linear' }}
      >
        <Sigil size={130} opacity={0.6} />
      </motion.div>

      {/* Innermost static */}
      <motion.div
        className="absolute"
        animate={{ scale: [1, 1.05, 1], opacity: [0.7, 1, 0.7] }}
        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
      >
        <Sigil size={70} opacity={0.9} />
      </motion.div>

      {/* Glow core */}
      <motion.div
        className="absolute rounded-full"
        animate={{ scale: [1, 1.3, 1], opacity: [0.5, 0.9, 0.5] }}
        transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
        style={{
          width: 50,
          height: 50,
          background: 'radial-gradient(circle, rgba(176,79,200,0.9) 0%, rgba(176,79,200,0) 70%)',
          filter: 'blur(10px)',
        }}
      />

      {/* Gold halo */}
      <motion.div
        className="absolute rounded-full"
        animate={{ opacity: [0.15, 0.35, 0.15] }}
        transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
        style={{
          width: 280,
          height: 280,
          border: '1px solid rgba(201,168,76,0.3)',
          borderRadius: '50%',
        }}
      />
    </div>
  );
}

export function MiniSigil({ size = 40, opacity = 0.5 }: Props) {
  const cx = size / 2;
  const cy = size / 2;
  const r = size * 0.42;

  const triangleUp = Array.from({ length: 3 }, (_, i) => {
    const a = (Math.PI * 2 / 3) * i - Math.PI / 2;
    return `${cx + r * Math.cos(a)},${cy + r * Math.sin(a)}`;
  }).join(' ');

  const triangleDown = Array.from({ length: 3 }, (_, i) => {
    const a = (Math.PI * 2 / 3) * i + Math.PI / 2;
    return `${cx + r * Math.cos(a)},${cy + r * Math.sin(a)}`;
  }).join(' ');

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} fill="none" style={{ opacity }}>
      <circle cx={cx} cy={cy} r={r} stroke="#d47fe6" strokeWidth="0.8" />
      <polygon points={triangleUp} stroke="#d47fe6" strokeWidth="0.8" />
      <polygon points={triangleDown} stroke="#c9a84c" strokeWidth="0.8" />
      <circle cx={cx} cy={cy} r={3} fill="#d47fe6" />
    </svg>
  );
}

export function ProcessIcon({ step }: { step: number }) {
  const icons = ['◈', '⬡', '✦', '◎'];
  return (
    <div className="relative flex items-center justify-center">
      <div
        className="w-16 h-16 rounded-full glass flex items-center justify-center"
        style={{
          border: '1px solid rgba(176,79,200,0.4)',
          boxShadow: '0 0 25px rgba(176,79,200,0.2)',
        }}
      >
        <span className="text-2xl gradient-orchid font-bold">{icons[step] || '◈'}</span>
      </div>
      <div
        className="absolute rounded-full pulse-glow"
        style={{
          inset: -8,
          background: 'radial-gradient(circle, rgba(176,79,200,0.12) 0%, transparent 70%)',
        }}
      />
    </div>
  );
}
